---
component: Questionnaire
module: "@tecton/react/components/questionnaire"
family: conversation
exports: [Questionnaire, QuestionnaireProgress, QuestionnaireItem, QuestionnaireTitle, QuestionnaireDescription, QuestionnaireChoices, QuestionnaireChoice, QuestionnaireChoiceDescription, QuestionnaireInput, QuestionnaireError, QuestionnaireActions, QuestionnairePrevious, QuestionnaireSkip, QuestionnaireNext, QuestionnaireSubmit]
notFor:
  - need: one labelled control with a description and an error, inside a form
    use: Field
  - need: a single group of radio options that is part of a larger form
    use: RadioGroup
related: [Field, RadioGroup, Dialog]
---

## Use it when

- The assistant asks a short, ordered set of questions before it acts: scope, constraints, review.
- One question is on screen at a time, with progress, back, skip and submit around it, and the answers are gathered once, on submit.

## Do

- Declare the questions once as `items` on `Questionnaire`, so progress, actions and shortcuts render before hydration.
- Give every `QuestionnaireItem` a `name`, mark it `required` or `multiple`, and put its options in `QuestionnaireChoices`.
- Read the answers in `onSubmit` from `new FormData(event.currentTarget)`; the root is the `form`.
- Navigate only with `QuestionnairePrevious`, `QuestionnaireSkip`, `QuestionnaireNext` and `QuestionnaireSubmit`, inside `QuestionnaireActions`.
- These parts are plain form elements, not React Aria: they take `disabled` and `onChange`, and `QuestionnaireInput` needs an `aria-label`.

## Don't

### CRITICAL A questionnaire hand-built from RadioGroup

Wrong:

```tsx
<div className="flex flex-col gap-5">
  <h3>What kind of change is this?</h3>
  <RadioGroup value={value} onChange={setValue}>
    <RadioGroupItem value="feature">New feature</RadioGroupItem>
  </RadioGroup>
  <Button onPress={() => send(value)}>Submit</Button>
</div>
```

Correct:

```tsx
<Questionnaire items={items} onSubmit={handleSubmit}>
  <QuestionnaireItem name="change" required>
    <QuestionnaireTitle>What kind of change is this?</QuestionnaireTitle>
    <QuestionnaireChoices>
      <QuestionnaireChoice value="feature">New feature</QuestionnaireChoice>
    </QuestionnaireChoices>
    <QuestionnaireError />
  </QuestionnaireItem>
  <QuestionnaireActions>
    <QuestionnaireSubmit />
  </QuestionnaireActions>
</Questionnaire>
```

`Questionnaire` is the `form` and each item is a `fieldset` whose `QuestionnaireTitle` is its `legend`, so the hand-built version puts nothing in `FormData`, enforces no `required`, and leaves the question unassociated with its answers.

### HIGH A plain submit Button in the actions row

Wrong:

```tsx
<QuestionnaireActions>
  <QuestionnaireNext />
  <Button type="submit">Submit</Button>
</QuestionnaireActions>
```

Correct:

```tsx
<QuestionnaireActions>
  <QuestionnairePrevious />
  <QuestionnaireNext />
  <QuestionnaireSubmit>Submit brief</QuestionnaireSubmit>
</QuestionnaireActions>
```

`QuestionnaireSubmit` is `hidden`, `inert` and `tabIndex={-1}` until the last item is the active one, so a plain button is reachable from the first question and submits the form with every later item still unanswered.

### MEDIUM React Aria props on a choice

Wrong:

```tsx
<QuestionnaireChoice value="refactor" isDisabled>Refactor</QuestionnaireChoice>
```

Correct:

```tsx
<QuestionnaireChoice value="refactor" disabled>Refactor</QuestionnaireChoice>
```

These parts come from `@shadcn/react/questionnaire`, not React Aria, so `isDisabled` is a type error the dev server strips instead of checking, then forwards to the `label` as an unknown attribute: no `data-disabled`, and the choice stays selectable.
