---
component: Table
module: "@tecton/react/components/table"
family: data
exports: [Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell, TableCaption]
notFor:
  - need: sorting, filtering, paging or column visibility over the rows
    use: TanStack Table
  - need: a list of rows with media, a title and actions rather than columns
    use: Item
related: [Item, TreeView, "TanStack Table"]
---

## Use it when

- Records of the same shape have to line up in columns: invoices, wells, run results.
- Rows are selectable, activatable, sortable or sometimes absent — React Aria gives all four on these parts.
- A footer totals the columns, or a caption names the table.

## Do

- Put `TableHead` children straight inside `TableHeader`; React Aria renders the header row itself, while `TableFooter` does take a `TableRow`.
- Name the grid with `aria-label` on `Table`, mark the identifying column `isRowHeader`, and give every `TableRow` an `id`: `selectionMode`, `selectedKeys` and `onSelectionChange` work off those keys, and a `Checkbox slot="selection"` fills itself in.
- Render the empty case with `TableBody`'s `renderEmptyState`, which is what the `data-empty:h-24 data-empty:text-center` rules are waiting for, and keep `className` on the parts to alignment and width (`text-right`, `w-24`).

## Don't

### CRITICAL A table built from divs and grid classes

Wrong:

```tsx
<div className="grid grid-cols-2 text-sm">
  <div className="bg-zinc-100 px-4 py-3 font-medium">Invoice</div>
  <div className="bg-zinc-100 px-4 py-3 font-medium">Status</div>
  <div className="px-4 py-3">INV001</div>
  <div className="px-4 py-3">Paid</div>
</div>
```

Correct:

```tsx
<Table aria-label="Invoices">
  <TableHeader>
    <TableHead id="invoice" isRowHeader>Invoice</TableHead>
    <TableHead id="status">Status</TableHead>
  </TableHeader>
  <TableBody>
    <TableRow id="INV001">
      <TableCell className="font-medium">INV001</TableCell>
      <TableCell>Paid</TableCell>
    </TableRow>
  </TableBody>
</Table>
```

The grid emits no `role="grid"`, `columnheader` or `rowheader`, so assistive technology reads a stream of unassociated cells with no row or column count, and `bg-zinc-100` is stock Tailwind the reset palette emits no CSS for — the header band is `bg-table-header` on `TableHead`.

### CRITICAL Activating a row with onClick

Wrong:

```tsx
<TableRow key={well.id} id={well.id} onClick={() => openWell(well.id)}>
  <TableCell>{well.name}</TableCell>
</TableRow>
```

Correct:

```tsx
<TableRow key={well.id} id={well.id} onAction={() => openWell(well.id)}>
  <TableCell>{well.name}</TableCell>
</TableRow>
```

React Aria's `Row` runs `delete DOMProps.onClick` before it renders the `<tr>`, so the handler never reaches the DOM; `onAction` is the row's activation hook and fires on Enter and Space as well as on a click.

### HIGH Sorting from a click handler on the header

Wrong:

```tsx
<TableHead id="email" onClick={() => setSort("email")}>Email</TableHead>
```

Correct:

```tsx
<Table aria-label="Payments" sortDescriptor={sort} onSortChange={setSort}>
  <TableHeader>
    <TableHead id="email" isRowHeader allowsSorting>Email</TableHead>
  </TableHeader>
  <TableBody>{rows}</TableBody>
</Table>
```

`allowsSorting` is what makes the column a sort control — it sets `aria-sort`, sorts on Enter and Space, draws the direction indicator and routes the change through the table's `onSortChange`; a bare `onClick` on the `th` answers a mouse and nothing else.
