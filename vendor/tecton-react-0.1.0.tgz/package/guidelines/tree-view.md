---
component: TreeView
module: "@tecton/react/tecton/tree-view"
family: data
exports: [TreeView, TreeViewItem, TreeViewItemContent, TreeViewAction, TreeViewVisibilityToggle, TreeViewCollection]
notFor:
  - need: stacked sections that expand, with no parent and child structure
    use: Accordion
  - need: a flat list of rows with media, a title and actions
    use: Item
related: [Accordion, Item, ColorSwatch]
---

## Use it when

- A hierarchy is browsed rather than read: a project tree, a field and well inventory, a layer list.
- Rows carry more than a label: selection, disabled, hidden, a colour, a count, a per-row menu.
- Arrow-key navigation, expansion and type-ahead have to work across the whole structure.

## Do

- Give `TreeView` an `aria-label`, and every `TreeViewItem` an `id` and a `textValue`.
- Put `TreeViewItemContent` first inside each `TreeViewItem`, then the child `TreeViewItem`s — or a `TreeViewCollection` with `items` for dynamic data.
- Pick the leading glyph with `kind="folder" | "item"` or replace it with `icon`; the chevron and the indent are handled for you.
- Hang the extras on `TreeViewItemContent`: `colorTag` (a `ColorSwatch`), `suffix` (a `Badge`), `endAdornment` (`TreeViewVisibilityToggle`, which names itself "Hide" plus the row's label with `aria-pressed` for the hidden state, and `TreeViewAction`).
- Drive state from `TreeView` — `selectionMode` with `selectedKeys`, `disabledKeys`, `expandedKeys` — and dim a row with `isHidden` on `TreeViewItem`.

## Don't

### CRITICAL A tree built from nested Collapsibles

Wrong:

```tsx
<Collapsible>
  <CollapsibleTrigger>Wells</CollapsibleTrigger>
  <CollapsibleContent className="pl-4">
    <Collapsible>
      <CollapsibleTrigger>34/10-A-12</CollapsibleTrigger>
      <CollapsibleContent className="pl-4">Completions</CollapsibleContent>
    </Collapsible>
  </CollapsibleContent>
</Collapsible>
```

Correct:

```tsx
<TreeView aria-label="Project" selectionMode="single" defaultExpandedKeys={["wells"]}>
  <TreeViewItem id="wells" textValue="Wells">
    <TreeViewItemContent kind="folder">Wells</TreeViewItemContent>
    <TreeViewItem id="a12" textValue="34/10-A-12">
      <TreeViewItemContent>34/10-A-12</TreeViewItemContent>
    </TreeViewItem>
  </TreeViewItem>
</TreeView>
```

Each `Collapsible` is its own widget, so the result is a pile of buttons with no `role="treegrid"`, no arrow-key or type-ahead movement between rows and no selection; `TreeView` is React Aria's `Tree` and gets all of it from `id`, `textValue` and the nesting.

### HIGH Indenting rows with padding classes

Wrong:

```tsx
<TreeViewItemContent className="pl-8">34/10-A-12</TreeViewItemContent>
```

Correct:

```tsx
<TreeViewItem id="wells" textValue="Wells">
  <TreeViewItemContent kind="folder">Wells</TreeViewItemContent>
  <TreeViewItem id="a12" textValue="34/10-A-12">
    <TreeViewItemContent>34/10-A-12</TreeViewItemContent>
  </TreeViewItem>
</TreeViewItem>
```

`TreeViewItemContent` writes `paddingInlineStart` as an inline style computed from React Aria's `level`, which no `className` can outrank, so the row keeps the depth it really has in the collection and `pl-8` is dead weight.

### MEDIUM A row without textValue

Wrong:

```tsx
<TreeViewItem id="balder">
  <TreeViewItemContent suffix={<Badge variant="info">12</Badge>}>Top Balder</TreeViewItemContent>
</TreeViewItem>
```

Correct:

```tsx
<TreeViewItem id="balder" textValue="Top Balder">
  <TreeViewItemContent suffix={<Badge variant="info">12</Badge>}>Top Balder</TreeViewItemContent>
</TreeViewItem>
```

`textValue` is the row's plain-text name for React Aria, and `TreeViewItemContent` wraps the label in chevron, icon, suffix and adornment spans, so without it the row is announced and type-ahead matched as the whole assembled row, badge included. With dynamic `items`, React Aria caches each rendered row, so a row that also reads state kept outside `items` (the hidden set behind `isHidden` and `TreeViewVisibilityToggle`, a selection map) does not update until that state is listed in `dependencies` on `TreeView` and on every `TreeViewCollection`: `dependencies={[hidden]}`.
