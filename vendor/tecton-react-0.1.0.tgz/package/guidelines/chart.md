---
component: ChartContainer
module: "@tecton/react/components/chart"
family: data
exports: [ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent, ChartStyle]
notFor:
  - need: one measured number with a unit and a change
    use: Stat
  - need: a value read against a fixed scale with named bands
    use: Meter
related: [Stat, Meter, Progress]
---

## Use it when

- Several values are compared over time or across categories: production by month, cost by discipline.
- The chart itself is Recharts — `BarChart`, `LineChart`, `AreaChart` and `PieChart` go inside `ChartContainer` unchanged.
- The series need one set of labels, colours and icons that the tooltip and the legend both read: that is the `ChartConfig`.

## Do

- Key the `ChartConfig` by `dataKey`, each entry with `label`, `color` (or `theme: { light, dark }`) and an optional `icon`, and pass it to `ChartContainer`.
- Take the colours from the theme: `var(--chart-1)` … `var(--chart-5)` are the Tecton accent fills, already paired for light and dark.
- Paint each series with the variable the container emits — `fill="var(--color-desktop)"`, `stroke="var(--color-mobile)"`.
- Give the container a size, `className="h-64 w-full"`, since the `ResponsiveContainer` inside measures its parent, and put `accessibilityLayer` on the Recharts chart.
- Add `ChartTooltip content={<ChartTooltipContent />}` and `ChartLegend content={<ChartLegendContent />}`; both read their labels and swatches from the same config.

## Don't

### CRITICAL Colouring series with Tailwind classes or a hex

Wrong:

```tsx
<ChartContainer config={{ desktop: { label: "Desktop" } }} className="h-64 w-full">
  <BarChart accessibilityLayer data={chartData}>
    <Bar dataKey="desktop" className="fill-blue-500" radius={4} />
    <Bar dataKey="mobile" fill="#60a5fa" radius={4} />
  </BarChart>
</ChartContainer>
```

Correct:

```tsx
<ChartContainer
  config={{
    desktop: { label: "Desktop", color: "var(--chart-1)" },
    mobile: { label: "Mobile", color: "var(--chart-2)" },
  }}
  className="h-64 w-full"
>
  <BarChart accessibilityLayer data={chartData}>
    <Bar dataKey="desktop" fill="var(--color-desktop)" radius={4} />
    <Bar dataKey="mobile" fill="var(--color-mobile)" radius={4} />
  </BarChart>
</ChartContainer>
```

`fill-blue-500` is a stock Tailwind colour the reset palette emits no CSS for, so that bar falls back to Recharts' default, and the hard-coded hex has no dark pair — only `color` in the config reaches `ChartStyle`, which writes `--color-<key>` once per theme and feeds the tooltip and legend swatches from the same value.

### CRITICAL A Recharts chart with no ChartContainer

Wrong:

```tsx
<BarChart width={600} height={300} data={chartData}>
  <Tooltip />
  <Bar dataKey="desktop" fill="#2563eb" radius={4} />
</BarChart>
```

Correct:

```tsx
<ChartContainer config={chartConfig} className="h-64 w-full">
  <BarChart accessibilityLayer data={chartData}>
    <ChartTooltip content={<ChartTooltipContent />} />
    <Bar dataKey="desktop" fill="var(--color-desktop)" radius={4} />
  </BarChart>
</ChartContainer>
```

`ChartContainer` is what supplies the config context, renders `ChartStyle` so `var(--color-<key>)` resolves, and wraps the chart in Recharts' `ResponsiveContainer`; a fixed `width` and `height` chart never reflows, and Recharts' own `Tooltip` ignores the theme instead of rendering the bordered popover the container styles.

### MEDIUM A config key that is not the dataKey

Wrong:

```tsx
const chartConfig = { Desktop: { label: "Desktop", color: "var(--chart-1)" } }
```

Correct:

```tsx
const chartConfig = { desktop: { label: "Desktop", color: "var(--chart-1)" } }
```

`ChartStyle` emits one `--color-<key>` per config key, so the `<Bar dataKey="desktop" fill="var(--color-desktop)" />` above it resolves to nothing and takes Recharts' default fill, while `ChartTooltipContent` looks each item up by its `dataKey` and shows the raw key instead of the label.
