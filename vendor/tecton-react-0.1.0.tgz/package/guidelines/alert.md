---
component: Alert
module: "@tecton/react/components/alert"
family: feedback
exports: [Alert, AlertTitle, AlertDescription, AlertAction]
notFor:
  - need: a confirmation that should disappear on its own
    use: toast
  - need: the state of a list or a page that has nothing in it
    use: Empty
  - need: a one-word status label inside a row or a header
    use: Badge
  - need: a message about a single form field
    use: FieldError
related: [Toaster, Empty]
---

## Use it when

- A message must stay on the page until the user reads or resolves it: a failed run, unsaved changes, a stale model.
- The message belongs to a region — above a form, inside a panel, at the top of a page — not to a single field.
- The message needs a severity colour, and sometimes an action beside it.

## Do

- `variant` is the severity (`default`, `info`, `success`, `warning`, `destructive`); `appearance` is the surface (`default` keeps the card background, `outline` is a coloured border, `filled` is the Tecton status surface).
- Compose `Alert > icon, AlertTitle, AlertDescription, AlertAction`, with the icon as a direct child of `Alert`.
- Put every button, including the dismiss control, inside `AlertAction` and wire it with `onPress`; a decision that blocks the user is an `AlertDialog`, not an alert.
- `className` is for width and placement (`max-w-md`, `mb-4`), never for the status colours.

## Don't

### CRITICAL Hand-colouring the severity with stock classes

Wrong:

```tsx
<Alert className="border-red-500 bg-red-500/10 text-red-700">
  <AlertTitle>Simulation failed</AlertTitle>
</Alert>
```

Correct:

```tsx
<Alert variant="destructive" appearance="outline">
  <AlertTitle>Simulation failed</AlertTitle>
</Alert>
```

`red-500` and `red-700` are not Tecton steps so the reset palette emits nothing for them, while `cn` has already dropped the variant's own `bg-card` and `border-border` — the alert renders as unstyled text.

### HIGH Putting the icon inside the title

Wrong:

```tsx
<Alert variant="warning" appearance="filled">
  <AlertTitle><TriangleAlertIcon /> Unsaved changes</AlertTitle>
  <AlertDescription>Three horizons have uncommitted edits.</AlertDescription>
</Alert>
```

Correct:

```tsx
<Alert variant="warning" appearance="filled">
  <TriangleAlertIcon />
  <AlertTitle>Unsaved changes</AlertTitle>
  <AlertDescription>Three horizons have uncommitted edits.</AlertDescription>
</Alert>
```

The two-column grid and the icon's `row-span-2` come from `has-[>svg]`, a direct-child selector, so an icon nested in the title leaves the alert in one column and the description no longer aligns under the title.

### MEDIUM An action that is not in AlertAction

Wrong:

```tsx
<Alert variant="success">
  <AlertTitle>Three FDA alternatives ranked</AlertTitle>
  <Button variant="ghost" size="icon-sm" aria-label="Dismiss" onPress={dismiss}><XIcon /></Button>
</Alert>
```

Correct:

```tsx
<Alert variant="success">
  <AlertTitle>Three FDA alternatives ranked</AlertTitle>
  <AlertAction>
    <Button variant="ghost" size="icon-sm" aria-label="Dismiss" onPress={dismiss}><XIcon /></Button>
  </AlertAction>
</Alert>
```

The alert clears its corner with `has-data-[slot=alert-action]:pr-18`, so a bare button joins the grid flow under the title instead of sitting in the reserved top-right corner.
