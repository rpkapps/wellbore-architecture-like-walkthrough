---
component: Collapsible
module: "@tecton/react/components/collapsible"
family: layout
exports: [Collapsible, CollapsibleTrigger, CollapsibleContent]
notFor:
  - need: several stacked sections with one open at a time
    use: Accordion
  - need: a panel that slides in over the page and is dismissed
    use: Sheet
  - need: short content anchored to the control that opened it
    use: Popover
related: [Accordion, Sheet, Popover]
---

## Use it when

- One region shows more detail on demand: advanced settings, a row's sub-fields, a long log.
- The control that toggles it is already on the page and stays where it is.
- Nothing else collapses with it — a second collapsible next to the first is an `Accordion`.

## Do

- Control it with `isExpanded` and `onExpandedChange` on `Collapsible`, or leave it uncontrolled with `defaultExpanded`.
- Style the trigger by giving a Tecton `Button` `slot="trigger"`; `CollapsibleTrigger` is a bare React Aria `Button` with no Tecton classes.
- Keep the revealed markup inside `CollapsibleContent`: it is the panel the trigger's `aria-expanded` and `aria-controls` refer to. `Collapsible` itself is one unstyled `div`, so its `className` is yours for the layout.

## Don't

### CRITICAL Radix open and onOpenChange

Wrong:

```tsx
<Collapsible open={showDetail} onOpenChange={setShowDetail}>
  <Button slot="trigger" variant="ghost" size="icon">
    <ChevronsUpDownIcon />
  </Button>
  <CollapsibleContent>{detail}</CollapsibleContent>
</Collapsible>
```

Correct:

```tsx
<Collapsible isExpanded={showDetail} onExpandedChange={setShowDetail}>
  <Button slot="trigger" variant="ghost" size="icon">
    <ChevronsUpDownIcon />
  </Button>
  <CollapsibleContent>{detail}</CollapsibleContent>
</Collapsible>
```

`Collapsible` is a React Aria `Disclosure` and runs its props through `filterDOMProps`, which keeps only `id`, `data-*`, labelling and global DOM events: `open` and `onOpenChange` are dropped outright, so the region stays uncontrolled, `showDetail` never changes and anything else keyed off it — a chevron, a count, a Save button — never updates.

### HIGH Rendering the region conditionally instead of in CollapsibleContent

Wrong:

```tsx
<Collapsible isExpanded={showDetail} onExpandedChange={setShowDetail}>
  <Button slot="trigger" variant="outline">Details</Button>
  {showDetail ? <div className="rounded-md border p-4">{detail}</div> : null}
</Collapsible>
```

Correct:

```tsx
<Collapsible isExpanded={showDetail} onExpandedChange={setShowDetail}>
  <Button slot="trigger" variant="outline">Details</Button>
  <CollapsibleContent><div className="rounded-md border p-4">{detail}</div></CollapsibleContent>
</Collapsible>
```

`Disclosure` hands the panel id to `CollapsibleContent` and the matching `aria-controls` to the `slot="trigger"` button, so a hand-rolled conditional leaves the trigger pointing at an element that is not in the document and the panel with no `role="group"`.

### MEDIUM A trigger with its own onPress

Wrong:

```tsx
<Collapsible isExpanded={showDetail} onExpandedChange={setShowDetail}>
  <Button variant="ghost" onPress={() => setShowDetail(!showDetail)}>Details</Button>
  <CollapsibleContent>{detail}</CollapsibleContent>
</Collapsible>
```

Correct:

```tsx
<Collapsible isExpanded={showDetail} onExpandedChange={setShowDetail}>
  <Button slot="trigger" variant="ghost">Details</Button>
  <CollapsibleContent>{detail}</CollapsibleContent>
</Collapsible>
```

`Disclosure` publishes the toggle, `aria-expanded` and `aria-controls` through `ButtonContext` under the `trigger` slot only, so a button without it gets an empty default slot: the region still opens, but the control announces no expanded state and drops out of the keyboard contract the panel is built on.
