---
component: PortalProvider
module: "@tecton/react/tecton/portal"
family: infrastructure
exports: [PortalProvider, usePortalContainer, usePortalTarget]
notFor:
  - need: the root of an independently deployed application, container included
    use: ThemeRoot
  - need: the resolved container inside an overlay you are writing yourself
    use: usePortalTarget
  - need: a right-to-left subtree
    use: DirectionProvider
related: [ThemeRoot, Dialog]
---

## Use it when

- One page holds several isolated React roots — micro frontends, embedded widgets — and each needs a body-level overlay container of its own.
- That container has to carry a root's scope class, mode class and ownership attributes, so the styles compiled for the root still reach its portalled overlays.
- An overlay must escape an `overflow: hidden` ancestor and still land somewhere marked, not in a bare `document.body`.

## Do

- Wrap the root of the subtree, not individual overlays: `Dialog`, `Sheet`, `Popover`, `Tooltip`, `Select`, `Combobox`, `DropdownMenu`, `CommandDialog` and `Drawer` all read the context.
- Create the container once at body level and pass it as `container`; pass a function instead when the element only exists after the first render.
- Clear an outer provider with `container={null}` — overlays then pass no container and React Aria applies its own default.
- Reach for `ThemeRoot` first: it creates, classes, syncs and removes that container and wires this provider for you.

## Don't

### CRITICAL document.body as the container in a page with several roots

Wrong:

```tsx
createRoot(mountNode).render(
  <PortalProvider container={document.body}>
    <AssetTracker />
  </PortalProvider>
)
```

Correct:

```tsx
const overlayRoot = document.createElement("div")
overlayRoot.className = "mfe-a"
overlayRoot.setAttribute("data-tecton-root", "")
document.body.append(overlayRoot)

createRoot(mountNode, { identifierPrefix: "mfe-a" }).render(
  <PortalProvider container={overlayRoot}>
    <AssetTracker />
  </PortalProvider>
)
```

The container earns its keep through the class and the marker it carries: a remote's utilities are wrapped in `@scope (.mfe-a) to ([data-tecton-root])`, so an overlay dropped straight into `document.body` falls outside that scope and renders with the host's styles or with none.

### HIGH An overlay portalled by hand with createPortal

Wrong:

```tsx
createPortal(<Dialog isOpen={isOpen} onOpenChange={setIsOpen}>{body}</Dialog>, overlayRoot)
```

Correct:

```tsx
<PortalProvider container={overlayRoot}>
  <Dialog isOpen={isOpen} onOpenChange={setIsOpen}>{body}</Dialog>
</PortalProvider>
```

`Dialog` portals itself through React Aria, so the outer `createPortal` only relocates the element that renders it: the modal still lands in `document.body`, and the container's classes and variables never reach it.

### MEDIUM Defaulting the target to document.body in a custom overlay

Wrong:

```tsx
function Inspector(props: React.ComponentProps<typeof PopoverPrimitive>) {
  const container = usePortalContainer()
  return <PopoverPrimitive {...props} UNSTABLE_portalContainer={container ?? document.body} />
}
```

Correct:

```tsx
function Inspector(props: React.ComponentProps<typeof PopoverPrimitive>) {
  const container = usePortalTarget()
  return <PopoverPrimitive {...props} UNSTABLE_portalContainer={container} />
}
```

React Aria reads any set `UNSTABLE_portalContainer` as "the caller has decided" and stops resolving the target itself, so pinning `document.body` throws away its own defaults — the root popover's container for submenus, and `document.body` only once hydration is over — which is why `usePortalTarget` returns `undefined` rather than a fallback.
