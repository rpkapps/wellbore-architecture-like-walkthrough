---
component: Panel
module: "@tecton/react/tecton/panel"
family: surfaces
exports: [Panel, PanelHeader, PanelTitle, PanelDescription, PanelActions, PanelContent, PanelFooter]
notFor:
  - need: a self-contained content block that grows with its text
    use: Card
  - need: the title block at the top of a page
    use: PageHeader
  - need: a panel that floats over the page and is dismissed
    use: Sheet
  - need: the application frame around the work area
    use: AppShell
related: [Card, AppShell, Sheet]
---

## Use it when

- A tool surface inside the application: a properties panel, an inspector, a dashboard section.
- The panel is given a height by its container and its body has to scroll inside it.
- Actions belong to the panel itself — in the header row, or pinned at the bottom.

## Do

- Compose it: `PanelHeader` with `PanelTitle`, `PanelDescription` and `PanelActions`, then `PanelContent`, then `PanelFooter`.
- Choose the surface with `variant="default" | "elevated" | "flat" | "outline"` and the padding with `size="sm" | "md" | "lg"`.
- Put the body in `PanelContent`: it is the flex child that carries `min-h-0 flex-1 overflow-auto`.
- Give the panel its height from the outside (`className="h-72"`, or an `AppShellAside`); the parts handle the rest.
- Keep one to three icon buttons in `PanelActions`; beyond that put an `Overflow` toolbar inside the slot and the title yields width to it.

## Don't

### HIGH A body that is not in PanelContent

Wrong:

```tsx
<Panel className="h-72">
  <PanelHeader>
    <PanelTitle>Well properties</PanelTitle>
  </PanelHeader>
  <div className="p-4">{properties}</div>
  <PanelFooter>
    <Button size="sm">Open</Button>
  </PanelFooter>
</Panel>
```

Correct:

```tsx
<Panel className="h-72">
  <PanelHeader>
    <PanelTitle>Well properties</PanelTitle>
  </PanelHeader>
  <PanelContent>{properties}</PanelContent>
  <PanelFooter>
    <Button size="sm">Open</Button>
  </PanelFooter>
</Panel>
```

`Panel` is `flex min-h-0 flex-col overflow-hidden`, and only `PanelContent` carries `flex-1 overflow-auto`, so a plain `div` in its place is clipped instead of scrolling and pushes the footer out of view.

### MEDIUM Painting the variant by hand

Wrong:

```tsx
<Panel className="rounded-lg border border-gray-200 bg-white px-6 py-4 shadow-md">
  <PanelTitle>Alternatives</PanelTitle>
</Panel>
```

Correct:

```tsx
<Panel variant="elevated" size="lg">
  <PanelHeader>
    <PanelTitle>Alternatives</PanelTitle>
  </PanelHeader>
</Panel>
```

The shadow is the `elevated` variant and the padding is the `size` scale, which the parts read through `--panel-px` / `--panel-py`; `border-gray-200` is stock Tailwind and emits no CSS, while `rounded-lg`, `px-6 py-4` and `shadow-md` override the radius, padding and shadow the variant already owns.
