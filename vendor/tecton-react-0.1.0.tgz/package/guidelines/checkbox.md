---
component: Checkbox
module: "@tecton/react/components/checkbox"
family: forms
exports: [Checkbox]
notFor:
  - need: one choice out of several mutually exclusive options
    use: RadioGroup
  - need: a setting that takes effect the moment it is flipped
    use: Switch
  - need: a legend and shared description over a list of checkboxes
    use: FieldSet
related: [Switch, Field]
---

## Use it when

- An independent yes/no value the user confirms by submitting the form.
- Several options from a list may be picked at once.
- A parent row summarising children that are partly selected (`isIndeterminate`).

## Do

- Control it with `isSelected` and `onChange(isSelected: boolean)`, or leave it uncontrolled with `defaultSelected`.
- Give it an `id` and point a `FieldLabel htmlFor` at it inside a `Field orientation="horizontal"`; add `FieldContent` when there is a description.
- Disable with `isDisabled` and put `data-disabled` on the `Field` so the label dims with it.
- Mark errors with `isInvalid` on the checkbox and `data-invalid` on the `Field`, then render the message in `FieldError`.
- Inside a `Table` with `selectionMode`, use `slot="selection"` instead of wiring state yourself.

## Don't

### CRITICAL Using checked and onCheckedChange from Radix

Wrong:

```tsx
<Field orientation="horizontal">
  <Checkbox id="terms" checked={agreed} onCheckedChange={setAgreed} />
  <FieldLabel htmlFor="terms">Accept the terms</FieldLabel>
</Field>
```

Correct:

```tsx
<Field orientation="horizontal">
  <Checkbox id="terms" isSelected={agreed} onChange={setAgreed} />
  <FieldLabel htmlFor="terms">Accept the terms</FieldLabel>
</Field>
```

React Aria reads `isSelected` and `onChange`; the Radix names are unknown props that never reach the hidden input, so the box toggles its own uncontrolled state and `agreed` never changes.

### HIGH Labelling the checkbox with a plain span

Wrong:

```tsx
<div className="flex items-center gap-2">
  <Checkbox id="terms" />
  <span className="text-sm">Accept the terms</span>
</div>
```

Correct:

```tsx
<Field orientation="horizontal">
  <Checkbox id="terms" />
  <FieldLabel htmlFor="terms">Accept the terms</FieldLabel>
</Field>
```

A `span` is not a label, so the hidden input has no accessible name and the text does not toggle it; `Field` also supplies the alignment and the disabled state the checkbox styles read.

### MEDIUM Colouring the checked box with a class

Wrong:

```tsx
<Checkbox id="ready" className="data-[selected=true]:bg-emerald-600" />
```

Correct:

```tsx
<Checkbox id="ready" />
```

The checked fill is already `bg-ghost-active-foreground` from the component, and `bg-emerald-600` is outside the Tecton palette, so the class generates no CSS.
