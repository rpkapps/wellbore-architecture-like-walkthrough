---
component: MessageScroller
module: "@tecton/react/components/message-scroller"
family: conversation
exports: [MessageScrollerProvider, MessageScroller, MessageScrollerViewport, MessageScrollerContent, MessageScrollerItem, MessageScrollerButton, useMessageScroller, useMessageScrollerScrollable, useMessageScrollerVisibility]
notFor:
  - need: a styled scroll region for content that does not grow at its end
    use: ScrollArea
  - need: the row layout of one turn inside the transcript
    use: Message
related: [Message, Marker, ScrollArea]
---

## Use it when

- A transcript grows while the reader is inside it: a reply streams in, or a group chat appends.
- Reopening a saved thread should land on the last turn, not on the absolute bottom edge, and a permalink, a search hit or a jump menu can drive it from outside the list.

## Do

- Compose all of it: `MessageScrollerProvider`, `MessageScroller`, `MessageScrollerViewport`, `MessageScrollerContent`, `MessageScrollerItem`, `MessageScrollerButton`.
- Put the behaviour on the provider: `autoScroll` (off by default), `defaultScrollPosition="last-anchor"`, `scrollPreviousItemPeek`.
- Give every row a stable `messageId`, `scrollAnchor` to the row that starts a turn, and the scroller its height from outside (`className="flex-1"` in a constrained parent).
- Drive it from anywhere inside the provider with `useMessageScroller`, `useMessageScrollerScrollable` and `useMessageScrollerVisibility`.

## Don't

### CRITICAL A transcript in a plain overflow-auto div

Wrong:

```tsx
<div className="h-full overflow-y-auto">{rows}</div>
```

Correct:

```tsx
<MessageScrollerProvider autoScroll defaultScrollPosition="last-anchor">
  <MessageScroller className="flex-1">
    <MessageScrollerViewport>
      <MessageScrollerContent>{rows}</MessageScrollerContent>
    </MessageScrollerViewport>
    <MessageScrollerButton />
  </MessageScroller>
</MessageScrollerProvider>
```

The div never follows a streamed reply, and it loses what the parts give for free: `role="region"` with `aria-label="Messages"` and a tab stop on the viewport, `role="log"` on the content, and the reader's place kept when older messages are prepended.

### CRITICAL The scroller frame without its provider

Wrong:

```tsx
<MessageScroller className="flex-1">
  <MessageScrollerViewport>
    <MessageScrollerContent>{rows}</MessageScrollerContent>
  </MessageScrollerViewport>
</MessageScroller>
```

Correct:

```tsx
<MessageScrollerProvider autoScroll>
  <MessageScroller className="flex-1">
    <MessageScrollerViewport>
      <MessageScrollerContent>{rows}</MessageScrollerContent>
    </MessageScrollerViewport>
  </MessageScroller>
</MessageScrollerProvider>
```

Every part reads the provider's context, so the page throws `useMessageScroller must be used within a MessageScroller.` — an error that names the frame you already rendered instead of the `MessageScrollerProvider` that is missing.

### HIGH Rows dropped straight into the content

Wrong:

```tsx
<MessageScrollerContent>
  {messages.map((message) => <Message key={message.id}>{message.content}</Message>)}
</MessageScrollerContent>
```

Correct:

```tsx
<MessageScrollerContent>
  {messages.map((message) => (
    <MessageScrollerItem key={message.id} messageId={message.id} scrollAnchor={message.role === "user"}>
      <Message>{message.content}</Message>
    </MessageScrollerItem>
  ))}
</MessageScrollerContent>
```

Registration happens on the item, which writes `data-message-id` and `data-scroll-anchor`, so unwrapped rows never anchor a new turn, are skipped by visibility tracking, and make `scrollToMessage` return `false`.
