---
component: Overflow
module: "@tecton/react/tecton/overflow"
family: presentation
exports: [Overflow, Toolbar, OverflowItem, OverflowLabel, OverflowGroup, OverflowDivider, OverflowSpacer, OverflowMenu, useIsOverflowItemVisible]
notFor:
  - need: two or three buttons welded into one control
    use: ButtonGroup
  - need: actions that appear only while rows are selected
    use: ActionBar
  - need: every action behind one button from the start
    use: DropdownMenu
related: [ButtonGroup, ActionBar, DropdownMenu]
---

## Use it when

- A row of controls has to survive a container that gets narrow: a panel toolbar, a table header, a card's action row.
- The actions matter enough to stay reachable, so hiding them outright is not acceptable.
- The row is measured by its own width, not by a breakpoint — the same toolbar sits in a wide page and a 320 px aside.

## Do

- Wrap every control that may leave the row in an `OverflowItem` with a stable `id`; leave the primary action unwrapped so it is fixed and never collapses.
- Put the text in an `OverflowLabel` and describe the menu entry with `label`, `icon`, `shortcut` and `onAction`.
- Decide who leaves first with `priority` (higher stays longer); the menu always keeps source order.
- Use `Toolbar` with an `aria-label` when the row is a toolbar (one tab stop, arrow keys) and `Overflow` when it is not, such as a chip row.
- Give a non-button its menu form through `overflow`: a `DropdownMenuSub` for a select or submenu, a `DropdownMenuItem` opening a `Dialog` for a text input, or `"never"` to pin the item in the row.

## Don't

### CRITICAL Bare controls in the row

Wrong:

```tsx
<Toolbar aria-label="Well actions">
  <Button variant="outline"><TagIcon data-icon="inline-start" />Add tag</Button>
  <Button variant="outline"><ShareIcon data-icon="inline-start" />Share</Button>
  <Button onPress={create}>New well</Button>
</Toolbar>
```

Correct:

```tsx
<Toolbar aria-label="Well actions">
  <OverflowItem id="tag" label="Add tag" icon={<TagIcon />} onAction={addTag}>
    <Button variant="outline"><TagIcon data-icon="inline-start" /><OverflowLabel>Add tag</OverflowLabel></Button>
  </OverflowItem>
  <OverflowItem id="share" label="Share" icon={<ShareIcon />} onAction={share}>
    <Button variant="outline"><ShareIcon data-icon="inline-start" /><OverflowLabel>Share</OverflowLabel></Button>
  </OverflowItem>
  <Button onPress={create}>New well</Button>
</Toolbar>
```

Only an `OverflowItem` registers itself with the row's store, so only it can be measured, collapsed or moved into the menu: a row of bare buttons is entirely fixed, no More button is ever rendered, and the row wraps or scrolls instead.

### HIGH Label text that is not in an OverflowLabel

Wrong:

```tsx
<OverflowItem id="export" label="Export" icon={<DownloadIcon />} onAction={exportRows}>
  <Button variant="outline"><DownloadIcon data-icon="inline-start" />Export</Button>
</OverflowItem>
```

Correct:

```tsx
<OverflowItem id="export" label="Export" icon={<DownloadIcon />} onAction={exportRows}>
  <Button variant="outline"><DownloadIcon data-icon="inline-start" /><OverflowLabel>Export</OverflowLabel></Button>
</OverflowItem>
```

The icon-only stage works by putting `sr-only` on `OverflowLabel` alone, so plain text keeps its width: the item never reaches a compact size, the measured pair is wrong, and the row skips the collapse stage and starts hiding items instead.

### HIGH The handler on the button instead of on the item

Wrong:

```tsx
<OverflowItem id="delete" label="Delete" icon={<Trash2Icon />} variant="destructive">
  <Button variant="destructive" onPress={remove}><Trash2Icon data-icon="inline-start" /><OverflowLabel>Delete</OverflowLabel></Button>
</OverflowItem>
```

Correct:

```tsx
<OverflowItem id="delete" label="Delete" icon={<Trash2Icon />} variant="destructive" onAction={remove}>
  <Button variant="destructive"><Trash2Icon data-icon="inline-start" /><OverflowLabel>Delete</OverflowLabel></Button>
</OverflowItem>
```

`onAction` is both the handler of the generated `DropdownMenuItem` and the `onPress` injected into the React Aria `Button` child through `ButtonContext`, so it fires in both places; left on the button alone, the More-menu entry is built with no handler and does nothing once the item is hidden.
