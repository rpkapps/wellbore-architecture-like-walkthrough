---
component: PageHeader
module: "@tecton/react/tecton/page-header"
family: surfaces
exports: [PageHeader, PageHeaderContent, PageHeaderEyebrow, PageHeaderTitle, PageHeaderDescription, PageHeaderNav, PageHeaderActions]
notFor:
  - need: the title row of a panel or an inspector
    use: PanelHeader
  - need: the top bar of the application frame
    use: AppShellHeader
  - need: a heading inside a card
    use: CardTitle
related: [Panel, AppShell, Card]
---

## Use it when

- The block at the top of a page: what the user is looking at, and what they can do to it.
- The title needs an eyebrow (a breadcrumb or category), a description, or section tabs.
- The actions have to survive a narrow window without the header stacking.

## Do

- Put the eyebrow, title and description inside `PageHeaderContent`; put the actions in `PageHeaderActions`.
- Leave the primary action unwrapped in `PageHeaderActions`, and wrap secondary ones in `OverflowItem` with a `priority` so they collapse first.
- Use `PageHeaderNav` for section tabs and give it an `aria-label`; it is a bare `nav`.
- Let `PageHeaderTitle` be the `h1`: one per page, no heading level or size set through `className`.

## Don't

### HIGH Title and actions as direct children of PageHeader

Wrong:

```tsx
<PageHeader>
  <PageHeaderTitle>Gullfaks field development</PageHeaderTitle>
  <PageHeaderDescription>Three alternatives.</PageHeaderDescription>
  <PageHeaderActions>
    <Button>New alternative</Button>
  </PageHeaderActions>
</PageHeader>
```

Correct:

```tsx
<PageHeader>
  <PageHeaderContent>
    <PageHeaderTitle>Gullfaks field development</PageHeaderTitle>
    <PageHeaderDescription>Three alternatives.</PageHeaderDescription>
  </PageHeaderContent>
  <PageHeaderActions>
    <Button>New alternative</Button>
  </PageHeaderActions>
</PageHeader>
```

`PageHeader` is a `flex flex-wrap` row, so without `PageHeaderContent` the title and the description become siblings of the action row: the title loses its truncation and its 60% cap, and the description wraps onto its own line.

### MEDIUM A hand-built header row instead of PageHeader

Wrong:

```tsx
<div className="flex items-center justify-between">
  <h1 className="text-2xl font-bold text-zinc-900">34/10-A-12</h1>
  <Button>Edit</Button>
</div>
```

Correct:

```tsx
<PageHeader>
  <PageHeaderContent>
    <PageHeaderTitle>34/10-A-12</PageHeaderTitle>
  </PageHeaderContent>
  <PageHeaderActions>
    <Button>Edit</Button>
  </PageHeaderActions>
</PageHeader>
```

`text-zinc-900` is stock Tailwind and emits no CSS under Tecton's reset palette, and a hand-built row has neither the title truncation nor the collapsing action row, so it overflows as soon as the window narrows.
