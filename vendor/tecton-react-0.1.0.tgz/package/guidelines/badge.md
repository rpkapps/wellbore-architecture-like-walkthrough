---
component: Badge
module: "@tecton/react/components/badge"
family: labels
exports: [Badge]
notFor:
  - need: a tag the user can select or remove
    use: Chip
  - need: a count or dot pinned to the corner of an icon or avatar
    use: CountBadge
  - need: a confirmation that disappears on its own
    use: toast
  - need: a keyboard key or a shortcut hint
    use: Kbd
related: [Chip, CountBadge]
---

## Use it when

- A static label names a status, a category or a state: "Draft", "Producing", "12 errors".
- The label carries a severity: `variant="success" | "warning" | "info" | "destructive"`.
- The label links to the thing it names, inside a table cell, a list row or a card header.

## Do

- Pick meaning with `variant`, weight with `appearance="solid" | "outline"`, height with `size="default" | "md" | "lg"` (20 / 24 / 28 px).
- Give an icon or a `Spinner` child `data-icon="inline-start"` or `data-icon="inline-end"` so the badge trims its padding on that side.
- Make it a link with `render={(props) => <a {...props} href="/wells/12" />}`; there is no `asChild`, and an outer `<a>` gets none of the badge's `[a]:hover:` rules.
- A category colour that no `variant` carries is the one documented exception: a Tecton palette pair, `className="bg-blue-120 text-blue-830"`, never a stock Tailwind colour. Otherwise `className` is for placement.

## Don't

### CRITICAL Hand-colouring a status label with className

Wrong:

```tsx
<Badge className="bg-green-600 text-white">Producing</Badge>
```

Correct:

```tsx
<Badge variant="success">Producing</Badge>
```

`cn` merges away the variant's `bg-primary`, and `green-600` is not a Tecton step, so the reset palette emits no rule at all and the badge renders with no background.

### HIGH Making a Badge clickable with a handler

Wrong:

```tsx
<Badge variant="info" onClick={() => setFilter("fault-seal")}>
  Fault seal
</Badge>
```

Correct:

```tsx
<ChipGroup
  aria-label="Filters"
  selectionMode="single"
  onSelectionChange={(keys) => setFilter([...keys][0])}
>
  <ChipList>
    <Chip id="fault-seal" variant="info">
      Fault seal
    </Chip>
  </ChipList>
</ChipGroup>
```

Badge renders a `span` with no `role`, no `tabIndex` and no key handling, so the label answers a mouse click and is unreachable by keyboard and silent to assistive technology.

### MEDIUM An icon child without data-icon

Wrong:

```tsx
<Badge variant="warning">
  <TriangleAlertIcon />
  Unsaved
</Badge>
```

Correct:

```tsx
<Badge variant="warning">
  <TriangleAlertIcon data-icon="inline-start" />
  Unsaved
</Badge>
```

The padding compensation is `has-data-[icon=inline-start]:pl-1.5`, so without the attribute the icon sits in full text padding and the badge is wider than every other badge in the row.
