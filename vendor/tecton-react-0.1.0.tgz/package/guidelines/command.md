---
component: Command
module: "@tecton/react/components/command"
family: selection
exports: [Command, CommandDialog, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem, CommandSeparator, CommandShortcut]
notFor:
  - need: picking a value for a form field
    use: Combobox
  - need: a menu of actions opened from a button
    use: DropdownMenu
  - need: a menu opened by right click
    use: ContextMenu
related: [Combobox, DropdownMenu]
---

## Use it when

- The user should reach commands and records by typing, from anywhere in the application.
- The surface is a palette, usually inside `CommandDialog`, rather than a field in a form.
- The list mixes groups of actions and wants keyboard-shortcut hints beside them.

## Do

- Run the action from `onAction` on `CommandItem`, or from `onAction(key)` on `CommandList` with an `id` per item.
- Give `CommandList` a `renderEmptyState` that returns `CommandEmpty`.
- Pass `textValue` to any item whose children are JSX rather than a plain string.
- Group with `CommandGroup heading="…"`, divide with `CommandSeparator`, hint keys with `CommandShortcut`.
- Open the palette with `CommandDialog` and its `open` / `onOpenChange` props, wrapping a `Command`.

## Don't

### CRITICAL The cmdk onSelect prop instead of onAction

Wrong:

```tsx
<CommandItem onSelect={() => router.navigate({ to: "/wells" })}>Go to wells</CommandItem>
```

Correct:

```tsx
<CommandItem onAction={() => router.navigate({ to: "/wells" })}>Go to wells</CommandItem>
```

`CommandItem` is a React Aria `MenuItem`, whose activation handler is `onAction`; `onSelect` is not in its props, so it is dropped and pressing Enter or clicking the row does nothing at all.

### HIGH JSX item children with no textValue

Wrong:

```tsx
<CommandItem onAction={openBilling}>
  <CreditCardIcon />
  <span>Billing</span>
</CommandItem>
```

Correct:

```tsx
<CommandItem textValue="Billing" onAction={openBilling}>
  <CreditCardIcon />
  <span>Billing</span>
</CommandItem>
```

`CommandItem` derives `textValue` only when its children are a plain string, so an item built from an icon and a `span` has none and the palette's filter and typeahead cannot match it.

### MEDIUM An empty search that renders nothing

Wrong:

```tsx
<Command>
  <CommandInput placeholder="Type a command or search…" />
  <CommandList>{items}</CommandList>
</Command>
```

Correct:

```tsx
<Command>
  <CommandInput placeholder="Type a command or search…" />
  <CommandList renderEmptyState={() => <CommandEmpty>No results found.</CommandEmpty>}>
    {items}
  </CommandList>
</Command>
```

`CommandList` is a React Aria `Menu`, and a collection with no matching items renders nothing unless `renderEmptyState` is given; `CommandEmpty` is what that function returns, not a child of the list.
